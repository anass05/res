package Beans;

public enum Grade {
	PA,PH,PES
}
