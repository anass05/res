package Beans;

public enum Profile {
Chef,Prof
}
